#include<stdio.h>
#include<stdlib.h>
void printMinMax(int num1 , int num2)
{
    if(num1>num2)
    printf("%d is greater",num1);
    else
    printf("%d is greater",num2);
}

int main()
{
    int a , b ;
    printf("enter the value of a ");
    scanf("%d",&a);
    printf("enter the value of b ");
    scanf("%d",&b);
    printMinMax(a,b);
    return 0;

}