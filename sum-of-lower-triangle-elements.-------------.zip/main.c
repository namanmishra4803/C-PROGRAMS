/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
void main(){
int size,i,j,sum=0;
printf("Enter the size of  matrix : ");
scanf("%d",&size);
int a[size][size];
for(i = 0; i < size; i++){
for(j = 0; j < size; j++){
printf("Enter the vale at [%d][%d] position :",i,j);
scanf("%d",&a[i][j]);
}
}
for(i = 0; i < size; i++){
for(j = 0; j < size; j++)
if(i>j)
{
printf("%d ",a[i][j]);
sum=sum+a[i][j];
}
printf("\n");
}
printf("The sum of the lower triangle is:%d\n",sum);
}
