#include <stdio.h>
#include<stdlib.h>

int Factorial(int num)
{
    int i , result  = 1;
    if(num<0)
    return -1;
    for(i=1;i<=num;i++)
    {
    result = result*i;
    }
    return result;
    }
int main()
{
    int NewNum;
    printf("please insert the number ");
    scanf("%d",&NewNum);
    printf("Factorial of %d is %d ", NewNum,Factorial(NewNum));
    return 0;
}
