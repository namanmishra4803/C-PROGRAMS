#include <stdio.h>
int main()
{
    int a = 15;
    int b = 30;
    int temp;
    printf("a = %d", a );
    printf("b = %d" , b );
   
    temp = a;
    a = b ; 
    b = temp ;
    printf("a = %d" , a );
    printf("b = %d" , b );
}




