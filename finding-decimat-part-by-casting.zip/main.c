#include <stdio.h>

int main()
{
    float data ;
    printf(" Enter the value of float data type : ");
    scanf("%f" , &data);
    
    printf("The value of int data type is %d" , (int)data);
    printf("The value of decimal part of data type %f" , data - (int)data);

    return 0;
}
