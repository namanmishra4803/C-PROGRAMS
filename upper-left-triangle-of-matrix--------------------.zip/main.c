/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int
main ()
{
  int i, j, row, col;


  printf ("Enter no. of rows: ");
  scanf ("%d", &row);
  printf ("\nEnter no. of column: ");
  scanf ("%d", &col);
  int array[row][col];
  for (i = 0; i < row; i++)
    {
      for (j = 0; j < col; j++)
	{
	  printf ("Enter a[%d][%d] value:", i, j);
	  scanf ("%d", &array[i][j]);
	}
    }


  for (i = 0; i < row; i++)
    {
      for (j = 0; j < col; j++)

	{
	  if (i>j)
	    {
	      printf ("%d\t", array[i][j]);
	    }
	  else
	    {
	      printf ("\t");
	    }

	}
      printf ("\n");

    }
  return 0;
}



