#include<stdio.h>
int main()
{
    int arr[4],aRr[4],Arr[10];
    int i ,j=0;
    for(i=0;i<5;i++)
    {
        scanf("%d",&arr[i]);
    }
    for(j=0;j<5;j++)
    {
        scanf("%d",&aRr[j]);
    }
    for(i=0;i<5;i++)
    {
        Arr[i]=arr[i];
        
    }
    for(i=5;i<11;i++)
    {
        Arr[i]=aRr[j];
    j++;
        
    }
    for(i=0;i<11;i++)
    {
        printf("%d",Arr[i]);
    }
    
    return 0;
}
