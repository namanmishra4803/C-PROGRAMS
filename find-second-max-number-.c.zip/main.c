#include <stdio.h>

int main(void) {
	// your code goes here
	int t;
	  scanf("%d", &t);
	  
	  while(t--)
	  {
	      int n, n1, n2;
	      
	      scanf("%d %d %d", &n, &n1, &n2);
        
	      if(n > n1 && n < n2 || n>n2 && n < n1)
	      {
	          printf("%d\n", n);
	      }
	      else if(n1 > n && n1 < n2 || n1>n2 && n > n1)
	      {
	          printf("%d\n", n1);
	      }
	      else 
	      {
	          printf("%d\n", n2);
	      }
	  }
	
	return 0;
}
