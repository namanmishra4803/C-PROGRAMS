#include <stdio.h>
#include <string.h>
int main()
{
    char name[6]="Aryan";
    char na_me[6];
    strcpy(na_me,name);
printf("The new string is %s",na_me);
    return 0;
}
