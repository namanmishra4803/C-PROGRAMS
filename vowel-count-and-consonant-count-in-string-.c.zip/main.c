#include <stdio.h>
#include <string.h>
int main()
{
    char str[100];
    int i,vc=0,cc=0;
    scanf("%s",str);
    for(i=0;str[i]!='\0';i++)
    {
        if(str[i]=='A' || str[i]=='E' || str[i]=='I' || str[i]=='O' || str[i]=='U' 
        || str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o' || str[i]=='u')
        vc++;
        else
        cc++;
    }
    printf("The vowel count and consonant count is %d %d",vc,cc);
    

    return 0;
}
