#include <stdio.h>
#include <math.h>
int main()
{
    int x , y ;
    int p;
    printf ("Enter the value of x");
    scanf("%d" , &x);
    printf("Enter the value of y");
    scanf("%d", &y);
    p= pow(x,y);
    printf("P= %d" , p);
    return 0;
}
