/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{ int age=16;
printf("%d\n",age);
printf("the reference of variable age\n ");
printf("%p\n",&age);
int *ptr= &age;
printf("the value of pointer \n");
printf("%p\n",ptr);
printf("the value of addresh to which it is pointing\n");
printf("%d\n",*ptr);

    return 0;
}
