#include <stdio.h>

int main()
{
    int p,t,r,si;
    printf("Enter the principal, time and rate");
    scanf("%d%d%d",&p,&t,&r);
    si=(p*t*r)/100;
    printf("The simple interest to be paid is %d",si);
    return 0;
}

