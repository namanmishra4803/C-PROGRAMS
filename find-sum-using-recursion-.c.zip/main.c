#include <stdio.h>
    int sum( int num)
    {
        if(num==1)
        return 1;
        return num + sum(num -1);
    }
    
    int main()
    {
        int num;
        int final_sum;
        printf("Enter the value of num : ");
        scanf("%d",&num);
        final_sum = sum(num);
        printf("The Final sum is %d", final_sum);
        
    
    

    return 0;
}
