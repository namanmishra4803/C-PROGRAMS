#include <stdio.h>
#include<stdlib.h>

float Findarea(float height , float width)
{
    float area;
    area = height*width;
    return area ;
}
int main()
{
    int height , width ;
    float area ;
    printf("Enter the height");
    scanf("%d",&height);
    printf("Enter the width");
    scanf("%d",&width);
    area = Findarea(height , width );
    printf("%f",area);
    return 0;
}
