#include <stdio.h>

int main()
{
  int arr[5]={1,2,3,4,5};
  int  i,max;
  max=arr[0];
  
  
  for(i=0;i<5;i++)
  {
      if(arr[max]>max)
      max=arr[i];
      
  }
      printf("MAx is %d",max);
  

    return 0;
}
