#include <stdio.h>

int main()
{
    int a;
    scanf("%d",&a);
    a%2==0?printf("a is evem"):printf("a is odd");
    

    return 0;
}
