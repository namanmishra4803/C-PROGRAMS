#include<stdio.h>
int main()
{
    int grade1 , grade2, grade3, grade4 , grade5 ;
    int average ;
    printf("Enter the grade1:" );
    scanf("%d" , &grade1);
    printf("Enter the grade2:" );
    scanf("%d" , &grade2);
    printf("Enter the grade3:" );
    scanf("%d" , &grade3);
    printf("Enter the grade4: ");
    scanf("%d" , &grade4);
    printf("Enter the grade5: ");
    scanf("%d" , &grade5);
    average =(grade1+grade2+ grade3+ grade4+grade5)/5 ;
    printf("Average = %d" , average);
    return 0;
}
    