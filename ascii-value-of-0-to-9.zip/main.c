#include<stdio.h>  
  
int main()  
{  
    int a   ;  
  
    for(a = 48; a <= 57; a++)  
    {  
        printf("ASCII value of %c is %d\n", a, a);  
    }  
  
    return 0;  
}  