#include <stdio.h>
#include<string.h>
int main()
{
    int i,len,flag=0;
    char string[]="arora";
    len=strlen(string);
    for(i<0;i<len;i++)
{
    if(string[i]!=string[len-i-1])
   { flag=2;
    break;
}}
    if(flag==2)
    printf("String is not palindrom");
    else
    printf("String is palindrome");
    return 0;
}
