#include <stdio.h>

int main()
{
    int arr[5],i,s;
    for(i=1;i<=5;i++)
    {
        scanf("%d",&arr[i]);
}
    for(i=1;i<=5;i++)
    {
        if(arr[i]<0)
        {
            printf("%d",arr[i]);
        }
    }
    

    return 0;
}
