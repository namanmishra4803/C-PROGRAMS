#include<stdio.h>
int main()
{
    float   celcius ;
    float fahrenheit;
    printf("enter the value of celcius : ");
    scanf("%f" , &celcius);
    
    fahrenheit = (celcius * 9/5 )+ 32 ;
    printf("The value of fahrenheit should be : %f " ,fahrenheit );
    return 0;
}