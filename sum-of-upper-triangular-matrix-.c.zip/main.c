#include <stdio.h>

int main()
{
    int i , j, n,sum=0;
    printf("Enter then value of rows and coloumns ");
    scanf("%d",&n);
    int a[n][n];
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
     for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
   if(j>=i)
   {
       sum=sum+a[i][j];
       
   }
           
        }
    }
printf("%d",sum);
    return 0;    
    }


