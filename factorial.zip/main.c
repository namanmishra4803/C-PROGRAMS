#include<stdio.h>

int main()
{
    long int c=1,a,i;
    scanf("%ld",&a);
    
    for(i=1;i<=a;i++)
    c=c*i;
    printf("%ld",c);
    

    return 0;
}
