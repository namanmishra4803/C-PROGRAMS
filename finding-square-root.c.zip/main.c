#include <stdio.h>
#include <math.h>
int main()
{
    double num, sqroot;
    
    
    printf("Enter a number: ");
    scanf("%lf", &num);
    
   
    sqroot = sqrt(num);
    
    
    printf("The square root of %.2lf is: %.2lf", num, sqroot);
    
    return 0;
}