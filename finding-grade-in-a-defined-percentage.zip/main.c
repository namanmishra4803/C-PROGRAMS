#include<stdio.h>
int main()
{
    float s1,s2,s3,s4,s5,perc ;
    printf("Enter the value of first subject : ");
    scanf("%f" , &s1);
    printf("Enter the value of second subject : ");
    scanf("%f" , &s2);
    printf("Enter the value of third subject : ");
    scanf("%f" , &s3);
    printf("Enter the value of fouth subject : ");
    scanf("%f" , &s4);
    printf("Enter the value of fifth subject : ");
    scanf("%f" , &s5);
    
    perc = (s1 + s2 + s3 + s4 + s5 ) / 5 ;
    
    if (perc > 90 && perc <=100)
    {
        printf("A grade ");
    }
    
    else if ( perc > 80 && perc <= 90)
    printf("B grade ");
    
    else if ( perc > 70 && perc <= 80)
    printf("B grade "); 
    
    else if ( perc > 60 && perc <= 70)
    printf("B grade ");
    
    else{ 
          printf("Padhayi kar le bhai nahi to fail ho jayega ");
        }
        return 0 ;
}