#include <stdio.h>

int main()
{  int a[100],n,i,value,pos;
   printf("Enter The Number Of The element: ");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
       printf("Enter The Elemnt: ");
       scanf("%d",&a[i]);
   }
   printf("The Array is: ");
   for(i=0;i<n;i++)
   {
       printf("%d ",a[i]);
   }
   printf("\n");
   printf("Enter The value you want to be add in any index: ");
   scanf("%d",&value);
   printf("Enter The Posotion of the Elemnt: ");
   scanf("%d",&pos);
   for(i=n;i>=pos;i--)
   {
       a[i]=a[i-1];
   }
    a[pos]=value;
    printf("The Updated Array is: ");
   for(i=0;i<=n;i++)0
   {
       printf("%d ",a[i]);
   }
   printf("\n");
    return 0;
}

