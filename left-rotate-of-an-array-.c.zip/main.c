#include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    int size;
    scanf("%d",&size);
    
int temp,i;
int arr[size];
for(i=0;i<size;i++)
{
    scanf("%d",&arr[i]);
}

while(n)
{   temp=arr[0];
    for(i=0;i<=size-2;i++)
       arr[i]=arr[i+1];
        arr[size-1]=temp;
        n--;
    
   
}
 for(i=0;i<size;i++)
    {
        printf("%d ",arr[i]);
    }
    return 0;
    
}