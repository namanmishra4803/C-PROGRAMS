#include <stdio.h>
#include<stdio.h>

void Maxdigit(int num)
{
    if(num<10 || num >99)
    printf("ITs not a two digit number");
    else
    {
        if(num%10>num/10)
        printf("the max in %d is %d",num,num%10);
        else
        printf("The max in %d is %d",num,num/10);
    }
}
int main()
{
    Maxdigit(91);

    return 0;
}
