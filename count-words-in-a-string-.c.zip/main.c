#include <stdio.h>
#include <string.h>
int main()
{
    char str[100];
    int i,c=0;
    scanf("%[^\n]s",str);
    for(i=0;i<strlen(str);i++)
    {
       if(str[i]==' ')
       c++;
        
    }
    printf("The number of words in %s is %d",str,c+1);
    

    return 0;
}

