#include <stdio.h>
#include <string.h>
int main()
{
    char firstname[30]="Chaturvedi";
    char surname[30]="Aryan ";
    strcat(surname,firstname);
    printf("The combined name is %s", surname);
    

    return 0;
}
