/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int
main ()
{
  int marks[10], i, n, sum = 0;
  double average;
  printf ("enter no of elements:-");
  scanf ("%d", &n);

  for (int i = 0; i < n; ++i)
    {
      printf ("enter no:%d:", i + 1);
      scanf ("%d", &marks[i]);
      sum += marks[i];
    }
  average = (double) sum / n;

  printf ("average=%.2lf", average);

  return 0;

}
