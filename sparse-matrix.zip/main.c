#include <stdio.h>

int main()
{
    int i , j ,r,c, a[10][10],c_1,c1;
    printf("Enter then value of rows and coloumns ");
    scanf("%d %d",&r,&c);
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
    {
    if(a[i][j]==0)
      {
        c_1++;
      }
    else{
    c1++;
    }
    }
    }
    if(c_1>c1)
    {
    printf("Sparse Matrix");
    }
    else
    {
        printf("Not a sparse matrix ");
    }
    return 0;
}
