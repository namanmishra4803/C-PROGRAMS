#include <stdio.h>
#include <string.h>
int main()
{
    char sentence[50];
    int i , c =0 ;
     printf("Enter the string : ");
     gets(sentence);
     
     for(i=0;i<strlen(sentence);i++)
     {
         if(sentence[i]==' ')
         c++;
     }
     c++;
     
     printf("The Number of Words in %s = %d\n",sentence ,c );
     

    return 0;
}
