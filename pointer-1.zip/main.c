/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
int a = 5;
int *ptr1;
ptr1=&a;
printf("thw value of a:-%d\n",a);
printf("the address of a:-%p\n",&a);
printf("the value of ptr1:-%d\n",*ptr1);
printf("the address of ptr1:-%p\n",ptr1);

}

