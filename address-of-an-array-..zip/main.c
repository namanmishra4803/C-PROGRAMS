#include <stdio.h>

int main()
{
    int i , j;
    int arr[2][3] = {{1,2,3},{3,2,1}};
    for(i=0;i<2;i++)
    {
        for(j=0;j<3;j++)
    {
        printf("Adress 0f array is arr[%d][%d]=%lu\n",i,j,&arr[i][j]);
    }
}
    
}