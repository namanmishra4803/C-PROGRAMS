#include <stdio.h>
void palindrome()
{
    int a,rem,sum=0;
    printf("Enter the number : ");
    scanf("%d",&a);
    int m=a;
    while(a>0){
        rem=a%10;
        sum=sum*10+rem;
    a/=10;
    }
    if(m==sum){
        printf("pelindrome\a");
    }
    else{
        printf("not pelindrome\a");
    }
}

void perfect(){
    int a,i,sum=0,m;
    printf("Enter the number");
    scanf("%d",&a);
    m=a;
    for(i=1;i<=a/2;i++){
        if(a%i==0){
            sum=sum+i;
        }
    }
    if(m==sum){
    printf("perfect");
    }
    else{
        printf("not perfect");
    }
    
}

int main()
{
  int check;
   
   printf("1 for palindrome \n2 for perfect\n");
   printf("Entered value is : ");
   scanf("%d",&check);
   switch(check){
       case 1: palindrome();
       break;
       case 2: perfect ();
       break;
       default: printf("WRong check\n");
   }

    return 0;
}

