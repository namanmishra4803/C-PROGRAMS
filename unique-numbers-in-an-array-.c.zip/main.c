#include <stdio.h>

int main()
{
    int n;
    scanf("%d",&n);
    int i , arr[n],j,unique_count=0,found_duplicate=0;
    for(i=0;i<n;i++)
    {
        scanf("%d",&arr[i]);
    }
     
     for(i=0;i<n;i++)
     {
         for(j=0;j<n;j++)
         {
             if(i==j)
             continue;
              if(arr[i]==arr[j]);
             {
                 found_duplicate=1;
                 break;
             }
         }
         if(found_duplicate!=1)
         {
         printf("Unique value is %d",arr[i]);
         unique_count++; 
         
         found_duplicate=0;
         }
     }
     printf("Unique count is %d",unique_count);
     
    return 0;
}

