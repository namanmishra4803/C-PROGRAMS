/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
     int a, b, c;
  printf ("enter the value a");
  scanf ("%d", &a);
  printf ("enter the value of b");
  scanf ("%d", &b);
 a=a+b;
 b=a-b;
 a=a-b;
  printf ("swap value of a is %d\n", a);
  printf ("swap value of b is %d", b);
  return 0;
}
