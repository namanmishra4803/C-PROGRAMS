#include <stdio.h>
#include <math.h>
int  cube(int a)
{
    int b;
   b= pow(a,3);
    return b;
}
int main()
{
    int a,b;
    scanf("%d",&a);
   b= cube(a);
   printf("%d",b);
    return 0;
}
