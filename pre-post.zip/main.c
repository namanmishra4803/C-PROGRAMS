
#include <stdio.h>

int main()
{
    // printf("Hello World");
    int a =8;
    printf("%d %d %d %d ",a++,a++,++a,++a);
    return 0;
}
