#include<stdio.h>
void main(){
    int a,rem,sum=0;
    scanf("%d",&a);
    int m=a;
    while(a>0){
        rem=a%10;
        sum=sum*10+rem;
    a/=10;
    }
    if(m==sum){
        printf("pelindrome\a");
    }
    else{
        printf("not pelindrome\a");
    }
}
