#include <stdio.h>
#include <string.h>
int
main ()
{
  char a[] = "apple";
  int b = strlen (a);
  printf ("%d", b);
}
