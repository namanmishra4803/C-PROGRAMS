#include <stdio.h>

int main()
{
    
    int arr[5]={1,2,3,4,5};
    int i ;
    for (i=0;i<5;i++)
    {
        
        
    
    printf("Elements are %d\n",arr[i]);
}
    return 0;
}
