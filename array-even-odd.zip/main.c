#include <stdio.h>

int main()
{
    int arr[5],i,even,odd;
    for(i=1;i<=5;i++)
    {
        scanf("%d",&arr[i]);
        
    }
    for(i=1;i<=5;i++)
{
    if(arr[i]%2==0)
    printf("Even =%d\n",arr[i]);
    else
    printf("odd=%d\n",arr[i]);
}

 return  0;
}



