#include <stdio.h>
#include<stdlib.h>
int main()
{
    int n,i,*ptr;
    printf("Enter te value of n : ");
    scanf("%d",&n);
    ptr= (int*)calloc(n,sizeof(int));
    for(i=0;i<n;i++)
{
    scanf("%d",(ptr+i));
}
printf("Enter the updated value of n");
scanf("%d",&n);
 int *ptr1=(int*)realloc(ptr,n*sizeof(int));
for(i=0;i<n;i++)
{
    printf("%d",*(ptr1+i));
}
    free(ptr1);
    return 0;
}
