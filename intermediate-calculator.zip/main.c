#include <stdio.h>
int main()
{
    int num1 , num2 ;
    char mo;
    printf("Enter the mo you want to use ");
    scanf("%c",&mo);
    printf("Enter the num1 :");
    scanf("%d",&num1);
    printf("Enter the num2 :");
    scanf("%d",&num2);
    switch(mo)
    {
        case'+':
        printf("%d %c %d= %d\n",num1,mo,num2,num1+num2);
        break;
        case'-':
        printf("%d %c %d = %d\n",num1,mo,num2,num1-num2);
        break;
        case'*':
        printf("%d %c %d= %d\n",num1,mo,num2,num1*num2);
        break;
        case'/':
        
        if(num2==0)
        printf("You can not divide by 0:");
        else
        printf("%d %c %d=%d\n",num1,mo,num2,num1/num2);
        break;
        case'%':
        if(num2==0)
        printf("You can not divide by 0:");
        else
        printf("%d %c %d=%d\n",num1,mo,num2,num1%num2);
        break;
        default:
        printf("Wrong statement");
        
        
    } 
    return 0;
}
