#include<stdio.h>
#include<stdlib.h>
int main()
{
    int grade ;
    printf(" Enter the Grade: ");
    scanf("%d",&grade);
    
    if (grade>=80)
    printf("Outstanding");
    
    else if (grade>=60)
    printf("Good");
    
    else 
    printf("Ohh you didn't pass the examination. ");
}