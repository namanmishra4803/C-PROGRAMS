#include <stdio.h>
int main()
{
    float a1,d,an ;
    int n ;
    printf("Enter the initial term (a1) :");
    scanf("%f" , &a1);
    printf("Enter the diffrence between Arithmetic Sequence");
    scanf("%f" , &d);
    printf("Enter the number of elements in arithmetic progression : ");
    scanf("%d" , &n);
    printf("The n-th term 0f Arithmetic squence = %f\n" , a1 + (n-1)*d );
    return 0;
}