#include <stdio.h>

int main()
{
    int i,k,j,c=0;
    char ch;
   char s[100],str[100];
   scanf("%[^\n]s",s);
   
   for(i=0;s[i];i++)
   c++;
   scanf("%c",&ch);
   scanf("%[^\n]s",str);
   for(j=0,i=c-1;str[j];i++,j++)
   {
       s[i]=str[j];
   }
   puts(s);
    return 0;
}
