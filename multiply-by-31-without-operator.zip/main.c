#include <stdio.h>

int main()
{
    int n,i ;
    printf("Enter the n ");
    scanf("%d",&n);
   i= (n<<5)-n;
    
printf("%d",i);
    return 0;
}
