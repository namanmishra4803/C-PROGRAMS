#include <stdio.h>

void swap_array()
{
    int n;
    scanf("%d",&n);
    int a[n],b[n];
    
    int temp,i;
    for(i=0;i<n;i++)
    {
        scanf("%d",&a[i]);
    }
    for(i=0;i<n;i++)
    {
        scanf("%d",&b[i]);
    }
    for(i=0;i<n;i++)
    {
    
    temp=a[i];
    a[i]=b[i];
    b[i]=temp;
    }
    for(i=0;i<n;i++)
    {
        printf("%d\n",a[i]);
    }
    for(i=0;i<n;i++)
    {
        printf("%d",b[i]);
    }
    
    
}


int main()
{
    swap_array();
    return 0;
}
