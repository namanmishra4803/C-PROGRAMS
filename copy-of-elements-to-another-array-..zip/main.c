#include<stdio.h>
int main()
{
    int arr[5],aRr[5];
    int i ;
    for(i=0;i<6;i++)
    {
        scanf("%d",&arr[i]);
    }
    for(i=0;i<6;i++)
    {
        aRr[i]=arr[i];
    }
    
    
    for(i=0;i<6;i++)
    {
        printf("%d",aRr[i]);
    }
    
    return 0;
}
