#include <stdio.h>
#include<stdlib.h>

typedef struct point 
{
    int x;
    int y;
}point;
void printpoint(point p1)
{
    printf("The first point is %d\n ",p1.x);
    printf("The second point is %d\n ",p1.y);
}
point inputpoint()
{
    point mypoint;
    printf("Enter the point 1 : ");
    scanf("%d",&mypoint.x);
    printf("Enter the point 2 : ");
    scanf("%d",&mypoint.y);
    return mypoint ;
}

int main()
{
 point p1=inputpoint();
 printf("Point before changes\n");
 printpoint (p1);
  p1.x += 1;
  p1.y += 3;
 printf("Print after changes\n");
 printpoint (p1);

    return 0;
}
