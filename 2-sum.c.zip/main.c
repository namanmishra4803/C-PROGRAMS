#include <stdio.h>
int main()
{
    int a , b , sum ;
    printf("Enter the value of A = ");
    scanf("%d" , &a);
    printf("Enter the value of B = ");
    scanf("%d" , &b);
    sum = a + b ;
    printf("Sum = %d" , sum);
    return 0;
}