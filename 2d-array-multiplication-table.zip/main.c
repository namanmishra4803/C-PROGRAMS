#include <stdio.h>

int main()
{
    int i ,j,siz_e=11;
    int arr[siz_e][siz_e];
    for (i=1;i<siz_e;i++)
    {
        for(j=0;j<siz_e;j++)
        {
            arr[i][j]=i*j;
            
        }
    }
    for (i=1;i<siz_e;i++)
    {
        for(j=0;j<siz_e;j++)
        {
            printf("%d ",arr[i][j]);
        }printf("\n");
}
    return 0;
}

