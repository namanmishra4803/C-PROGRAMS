#include <stdio.h>

int main(){
    int a,i,sum=0,m;
    scanf("%d",&a);
    m=a;
    for(i=1;i<=a/2;i++){
        if(a%i==0){
            sum=sum+i;
        }
    }
    if(m==sum){
    printf("perfect");
    }
    else{
        printf("not perfect");
    }
} 

