#include<stdio.h>
int main()
{
    char grade;
    printf("Enter the grade(A-D)");
    scanf("%c",&grade);
    switch(grade)
    {
        case 'A':
        printf("Grade is between 90-100");
        break;
        case 'B':
        printf("Grade is between 80-90");
        break;
        case 'C':
        printf("Grade is between 70-80");
        break;
        case 'D':
        printf("Grade is between 60-70");
        break;
        default:
        printf("Try again");
        break;
        
    }
    return 0;
}
