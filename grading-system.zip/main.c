#include<stdio.h>
int main()
{
    char grade;
    printf("Enter the grade (A-F)");
    scanf("%c",&grade);
    
    if ( grade == 'A')
    printf("grade is between 90-100");
    else if ( grade == 'B')
    printf("grade is between 80-90");
    else if ( grade == 'C')
    printf("grade is between 70-80");
    else if ( grade == 'D')
    printf("grade is between 60-70");
    else  
    printf("Error Try again");
    
    
    
}