#include <stdio.h>
#include<stdlib.h>
struct date {
    int day;
    int month ;
    int year;
};
int main()
{
    struct date placement_date;
    printf("Enter day");
    scanf("%d",&placement_date.day);
    printf("Enter month");
    scanf("%d",&placement_date.month);
    printf("Enter year");
    scanf("%d",&placement_date.year);
    printf("The date is %d %d %d",placement_date.day,placement_date.month,placement_date.year);


    return 0;
}
