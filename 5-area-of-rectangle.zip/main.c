#include <stdio.h>
int main()
{
    int l , b  ;
    int area;
    printf("Enter the value of l : ");
    scanf("%d" , &l);
    printf("Enter the value of b : ");
    scanf("%d" , &b);
    area = l*b;
    printf("Area = %d" , area);
    return 0;
    
}