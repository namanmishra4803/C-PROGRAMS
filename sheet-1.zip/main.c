Sheet-1(Introduction f C)
1.	Point out which of the following variable names are invalid.
●	Anand_gupta
●	Ruchigupta
●	Empdept
●	ROLLNO
●	Iamagoodboy
2.	Point out which of the following C constants are invalid. ( All correct )

●	0002
●	134.786
●	20
●	0xfff
●	.067
●	-11e-13
●	0xgff ;;
●	0x23.67;;
What will be the output of the following programs:
3.	#include <stdio.h>
int main()
{
printf("%05d,%5d,%-5d",32,32,32);
return 0;
} 
4.	#include <stdio.h>
int main()
{
	printf("%6.3f,%06.3f,%09.3f,%9.3f,%6.0f,%6.0f", 45.6,45.6,45.6,45.6,45.4,45.6);
return 0;
}
5.	#include <stdio.h>
int main()
{
printf("%d %d %d %d\n",15,015,0x15,0X15);
return 0;
} 15 13 21 21 
6.	#include <stdio.h>
int main()
{
	printf("%d %c",'A','A');
return 0;
} 65 A
7.	 #include <stdio.h>
int main()
{
printf("%d %o %x %X\n",15,15,15,15);
return 0;
}15 17 f F 
8.	 #include <stdio.h>
int main()
{
char ch;
int b;
float a;
printf("ch occupied %d size of char  %d\n",sizeof(ch),sizeof(char));

printf("b  occupied %d size of int   %d\n",sizeof(b),sizeof(int));

printf("a  occupied %d size of float %d\n",sizeof(a),sizeof(float));
return 0;  
} a occupied 4 size of float 4 
9.	#include <stdio.h>
int main()
{
inti = 5, j = 10, k = 15;
printf("%d ", sizeof(k /= i + j));
printf("%d", k);
return 0;
} 4 15
10.	  #include <stdio.h>
int main()
{
    //Assume sizeof character is 1 byte and sizeof integer is 4 bytes
printf("%d", sizeof(printf("Anand")));
return 0;
} 4
11.	#include <stdio.h>
int main()
{
int i = 12;
int j = sizeof(i++);
printf("%d  %d", i, j);
return 0;
} 12 4
12.	#include <stdio.h>
int main()
{
printf("size of '9'= %d \n", sizeof('9'));
printf("size of  9 = %d \n", sizeof(9));
return 0;
} 4 4
13.	#include <stdio.h>
int main()
{
printf("%d %d %d %d %d\n",sizeof(032),sizeof(0x32),sizeof(32),sizeof(32U),sizeof(32L));
printf("%d %d %d",sizeof(32.4),sizeof(32.4f),sizeof(32.4F));
return 0;
} 4 4 4 4 8 
  8 4 4
14.	#include <stdio.h>
int main()
{
printf("\nab");	
	printf("\bsi");	
	printf("\rha");
} hai
15.	#include <stdio.h>
int main()
{
	printf("%d",sizeof('\n'));
return 0;
} 4
16.	#include <stdio.h>
int main()
{
char p=307;
printf("%d %d %c\n",2147483649,p,p);
return 0;
} - me value 51 3 
17.	#include <stdio.h>
int main()
{
printf("c:\tc\bin");
printf("c:\\tc\\bin");
printf("hello.world\"");
} c :     inc:\tc\binhello.world"
18.	#include <stdio.h>
int main()
{
printf("hello.world\");
} error
19.	 #include <stdio.h>
int main()
{
printf("%f  %e  %g",7.23400,7.23400,7.23400);
} f copy e dega e+00 g 0 hata dega 
20.	#include <stdio.h>
int main()
{
printf("%f %d",4,123.123);
} dono ulte print hoge float extra 0 lagayega
21.	#include <stdio.h>
int main()
{
printf(" \"%%d %%f\"",123,123.2); 
}"%d %f"
22.	#include <stdio.h>
int main()
{
printf("%*d", 7, 123); 
} 123
23.	#include <stdio.h>
int main()
{
printf("%d", printf("%s", "anand"));
}anand5
24.	#include <stdio.h>
int main()
{
printf("%d %c\n");
printf("%d %c\n");
return 0;
} 1216070304
25.	 #include <stdio.h>
int main()
   {
int x= 231456478889;
float y= 3.4e100;
printf("x=%d\ny=%f\n",x,y);
printf("size of x =%d\nsize of y =%d\n",sizeof(x),sizeof(y));
return 0;
    } size of x is 4 size of y is  4
26.	#include <stdio.h>
int main()
{
int a;
float b;
    a=5.999999;
    b=5;
printf("a=%d, b=%f",a,b);
return 0;
} a = 5 b = 5.000000
27.	#include <stdio.h>
	int main()
   {
printf("%d, %f\n",4,4);
printf("%d, %f",4.0,4.0);
return 0;
} 4 , 0.000000
-790752608 , 4.000000

28.	#include <stdio.h>
int main()
{
char arr[100];
int b;
printf("%d", scanf("%s %d", arr,&b));
// Suppose that input value given for above scanf is Ruchi 7
return 0;
} 
29.	   #include <stdio.h>
int main()
  {
	printf(3 + "anandgupta");
	return 0;
  } ndgupta
30.	#include <stdio.h>
int main() 
        {
int x = printf("Anandgupta");
printf(" %d", x);
return 0;
        } Anandgupta 10
31.	#include <stdio.h>
int main()
{
int a = 10;
int b = 15;
printf("%d",(a + 1),(b = a + 2));
printf(" %d",b);
return 0;
} 

