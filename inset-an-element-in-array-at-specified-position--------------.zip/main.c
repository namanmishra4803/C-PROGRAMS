/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#define MAX_SIZE 100
//function declation 
int
main ()
{
  int arr[MAX_SIZE];
  int  i,size,num,pos;

  printf ("Enter size: ");
  scanf ("%d", &size);
  printf ("Enter elements : ");
  for (i = 0; i < size; i++)
    {
      scanf ("%d", &arr[i]);
    }
    
    printf("enter element to insert:");
    scanf("%d",&num);
    printf("enter the element position:");
    scanf("%d",&pos);
    
    if(pos>size+1||pos<=0)
    {
        printf("invalid position! please enter the position between 1 to %d",size);
    }
    else
    {
        for(i=size;i>=pos;i--)
        {
            arr[i]=arr[i-1];
        }
        arr[pos-1]=num;
        size++;
        
        printf("array elemnt after inserting:");
        for(i=0;i<size;i++) 
        {
            printf("%d\t",arr[i]);
        }
    }
  return 0;
}