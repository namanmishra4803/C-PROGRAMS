#include<stdio.h>
int main()
{
    int a , b , c , max , min  ;
    printf("Enter the value of a : ");
    scanf("%d ", &a);
    printf("Enter the value of b : ");
    scanf("%d ", &b);
    printf("Enter the value of c : ");
    scanf("%d ", &c);
    
    max = a ;
    min = b ;
    if (a<b)
    {
        max = b ;
        min = a;
         
    }
    if (max < c) 
    max = c;
    
    if (c < min) 
    
        min = c ;
        
        printf("Maximun of the three numbers is %d " , max);
        printf("Minimum of the three numbers is %d " , min);
        
        return 0;
    }