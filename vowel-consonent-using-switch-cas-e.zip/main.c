#include <stdio.h>

int main()
{
    char c;
    scanf("%c,&c");
    switch((c>='a'&&c<='z') || (c>='A'&&c<='Z'))
    {
        case 1: {
            switch(c=='a'||c=='e'||c=='i'||c=='o'||c=='u' ||c=='A'||c=='E'||
            c=='I'||c=='O'||c=='U')
            {
                case 1: printf("It is vowel");
                case 0: printf("Consonent");
            }
            break;
            case 0:
            printf("Enter corrcet Value");
        }
        
    }

    return 0;
}
