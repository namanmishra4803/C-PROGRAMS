#include <stdio.h>
#include<stdlib.h>

float Findavg(int grade1, int grade2, int grade3)
{
    float avg;
    avg = (grade1+grade2+grade3)/3.0;
    return avg;
}
int main()
{
    int g1,g2,g3;
    scanf("%d%d%d",&g1,&g2,&g3);
    
    printf("avg = %f\n",Findavg(g1,g2,g3));

    return 0;
}
