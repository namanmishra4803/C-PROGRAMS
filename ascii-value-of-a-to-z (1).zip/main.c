#include<stdio.h>  
  
int main()  
{  
    int a ;  
  
    for(a = 97; a <= 122; a++)  
    {  
        printf("ASCII value of %c is %d\n", a, a);  
    }  
  
    return 0;  
}  