#include <stdio.h>

int main()
{
    int n ;
    scanf("%d",&n);
    int i,j,a[n][n],b=0;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    for(i=0;i<n;i++)
     {
      for(j=0;j<n;j++)
       {
        if(i==j)
     b=b+a[i][j];
       }
     }
     printf("%d",b);
    return 0;
}
