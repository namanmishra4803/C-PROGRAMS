#include <stdio.h>
int main()
{
    int diameter , r ;
    printf("Enter the value of radius = ");
    scanf("%d" , &r);
    diameter = 2*r;
    printf("Diameter = %d" , diameter);
    return 0;
}