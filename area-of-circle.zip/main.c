#include <stdio.h>
int area(int r)
{
    float a;
    a=3.14*r*r;
    return r;
}
int main()
{
    float a;
    int r;
    scanf("%d",&r);
    a=3.14*r*r;
printf("%f",a);
    return 0;
}
