#include <stdio.h>

int main()
{  int a[100],n,i,value;
   printf("Enter The Number Of The element: ");
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
       printf("Enter The Elemnt: ");
       scanf("%d",&a[i]);
   }
   printf("The Array is: ");
   for(i=0;i<n;i++)
   {
       printf("%d ",a[i]);
   }
   printf("\n");
   printf("Enter The value you want to be add in first index: ");
   scanf("%d",&value);
   for(i=n;i>=0;i--)
   {
       a[i]=a[i-1];
   }
    a[0]=value;
    printf("The Updated Array is: ");
   for(i=0;i<=n;i++)
   {
       printf("%d ",a[i]);
   }
   printf("\n");
    return 0;
}

