/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int
main ()
{
  int i, j, row, col;


  printf ("Enter no. of rows: ");
  scanf ("%d", &row);
  printf ("\nEnter no. of column: ");
  scanf ("%d", &col);
  int array[row][col];
  for (i = 0; i < row; i++)
    {
      for (j = 0; j < col; j++)
	{
	  printf ("Enter a[%d][%d] value:", i, j);
	  scanf ("%d", &array[i][j]);
	}
    }


  for (i = 0; i < col; i++)
    {
      for (j = 0; j < row; j++)

	{
	  
	    
	      printf ("%d\t", array[j][i]);
	    
	  
	}
	      printf ("\n");
	 

	}
      printf ("\n");

  
  return 0;
}


