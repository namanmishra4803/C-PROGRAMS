#include <stdio.h>

int main()
{
    int arr[5]={1,2,3,4,5};
    int i ,ec=0,oc=0;
    for(i=0;i<5;i++)
    {
        scanf("%d",&arr[i]);
    }
    for(i=0;i<5;i++)
    {
        if(arr[i]%2==0)
        ec=ec+1;
        else
        oc=oc+1;
        
        
    }
    printf("even count is %d and odd count is %d",ec,oc);
    

    return 0;
}

