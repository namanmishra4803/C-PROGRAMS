#include <stdio.h>
#include <string.h>
int main()
{
    char name[5]="Rudra";
printf("The length of string is %ld",strlen(name));
    return 0;
}
