#include <stdio.h>

int main()
{
    int i;
    int arr[5] = {1,2,3,4,5};
    for (i=4;i>=0;i--)
    {
        printf("the array is %d\n", arr[i]);
    }

    return 0;
}
