#include <stdio.h>

    int sum_of_digits(int num)
    {
        if(num<=9)
        return num;
        return sum_of_digits(num%10) + sum_of_digits(num/10);
    }

    
int main()
{
    int num;
    scanf("%d",&num);
    printf("%d",sum_of_digits(num));
}
