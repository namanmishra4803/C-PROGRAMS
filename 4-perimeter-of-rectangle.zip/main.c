#include <stdio.h>
int main()
{
    int l , b  ;
    int perimeter;
    printf("Enter the value of l : ");
    scanf("%d" , &l);
    printf("Enter the value of b : ");
    scanf("%d" , &b);
    perimeter = 2*(l+b);
    printf("Perimeter = %d" , perimeter);
    return 0;
    
}