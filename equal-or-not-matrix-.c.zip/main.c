#include <stdio.h>

int main()
{
    int n,flag=0;
    scanf("%d",&n);
    int i,j,a[n][n],b[n][n];
    printf("Enter The First Matrix: ");
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&a[i][j]);
        }
    }
    printf("Enter The Second Matrix: ");
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            scanf("%d",&b[i][j]);
        }
    }
    for(i=0;i<n;i++){
        
        for(j=0;j<n;j++)
        {     
            if(a[i][j]==b[i][j])
            {
                flag=1;            
                break;
            }
            }
        
        }
    if(flag)
    printf("Equal Matrix");
    else
    printf("Not Equal Matrix");
    

    return 0;
}
