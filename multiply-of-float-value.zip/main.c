#include<stdio.h>
int main()
{
    float a , b , c ;
    printf("Enter the value of a ");
    scanf("%f" , &a);
    printf("Enter the value of b ");
    scanf("%f" , &b);
    
    c = a*b ;
    
    printf("c = %f" , c);
    return 0;
}
    
    