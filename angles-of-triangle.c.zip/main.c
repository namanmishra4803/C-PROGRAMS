#include <stdio.h>

int main()
{
    int a , b , c ;
    printf("Enter the angles : ");
    scanf("%d %d" , &a , &b );
    
    c = 180-(a+b);
    printf("The valuer of c is = %d" , c);

    return 0;
}
