#include <stdio.h>

int count( int num)
{
    if (num<=9)
    return 1;
    return 1 + count(num/10);
}
int main()
{
    int num;
    printf("Enter the value of num");
    scanf("%d",&num);
    printf("%d",count(num));

    return 0;
}
