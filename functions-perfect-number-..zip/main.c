#include <stdio.h>
#include<stdlib.h>

void Perfectnum()
{
    int i,n,m,s=0;  
    scanf("%d",&n);
    m = n /2;
    
    for(i=1;i<=m;i++)
    {
        if(n%i==0)
        s=s+i;
    }
        if (s==n)
        printf("Perfect number");
        else
        printf("Not a perfect number");
    
}
int main()
{
    Perfectnum();
}
